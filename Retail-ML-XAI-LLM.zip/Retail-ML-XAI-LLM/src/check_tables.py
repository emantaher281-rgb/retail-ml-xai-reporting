"""
Consistency check for the segmentation tables.

Reconstructs the customer-weighted global mean from the exported per-cluster
benchmark table, recomputes each cluster's percentage deviation, and asserts
that the sign agrees with the raw profile. Run after the segmentation
notebook:

    python src/check_tables.py

Exits non-zero if any sign disagrees, so it can be wired into CI.
"""

import json
import os
import sys

import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT_DIR = os.path.join(BASE_DIR, "outputs", "segmentation")
BENCH = os.path.join(OUT_DIR, "seg_cluster_benchmarks.csv")

# Columns in the benchmark export mapped to the LRFMV feature they represent.
FEATURE_COLUMNS = {
    "avg_monetary": "Monetary",
    "avg_recency": "Recency",
    "avg_freq": "Frequency",
    "avg_length": "Length",
}

if not os.path.exists(BENCH):
    sys.exit("Not found: %s\nRun notebooks/01_customer_segmentation.ipynb first."
             % os.path.relpath(BENCH, BASE_DIR))

bench = pd.read_csv(BENCH)
n_total = bench["customers"].sum()

print("=" * 74)
print("SEGMENTATION TABLE CONSISTENCY CHECK")
print("=" * 74)
print("Clusters: %d    Customers: %d" % (len(bench), n_total))

failures = []
report = {}

for col, feature in FEATURE_COLUMNS.items():
    if col not in bench.columns:
        continue

    # Customer-weighted global mean, reconstructed from the cluster table only.
    global_mean = (bench[col] * bench["customers"]).sum() / n_total

    print("\n%s   weighted global mean = %.2f" % (feature, global_mean))
    report[feature] = {"global_mean": round(float(global_mean), 4), "clusters": {}}

    for _, row in bench.iterrows():
        cid = int(row["cluster_id"])
        raw = float(row[col])
        pct = (raw - global_mean) / global_mean * 100.0

        # The sign of the deviation must match the side of the mean the raw
        # value falls on. These are two views of one quantity; disagreement
        # means a reporting or label-mapping error, not a modelling one.
        expected_sign = "+" if raw > global_mean else "-"
        actual_sign = "+" if pct > 0 else "-"
        ok = expected_sign == actual_sign

        status = "ok" if ok else "MISMATCH"
        print("   cluster %d  raw=%10.2f  deviation=%+8.1f%%   %s"
              % (cid, raw, pct, status))

        report[feature]["clusters"][str(cid)] = {
            "raw": round(raw, 4),
            "pct_deviation": round(float(pct), 4),
        }

        if not ok:
            failures.append((feature, cid, raw, pct))

print("\n" + "=" * 74)

out_path = os.path.join(OUT_DIR, "table_consistency_report.json")
with open(out_path, "w") as fh:
    json.dump(report, fh, indent=2)
print("Report written -> %s" % os.path.relpath(out_path, BASE_DIR))

if failures:
    print("\nFAILED: %d deviation sign(s) disagree with the raw profile."
          % len(failures))
    for feature, cid, raw, pct in failures:
        print("   %s / cluster %d: raw=%.2f but deviation reported as %+.1f%%"
              % (feature, cid, raw, pct))
    sys.exit(1)

print("\nPASSED: every deviation sign agrees with the weighted global mean.")
