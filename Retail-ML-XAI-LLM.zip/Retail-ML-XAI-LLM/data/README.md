# Dataset

## File

```
data/Customer_Segmentation&Sales_Forecasting_Dataset.csv
```

Transaction-level retail records. The file is **not** committed to this
repository; obtain it from the source below and place it at the path above.

## Permanent identifier

| Field | Value |
|---|---|
| Source / repository | `<fill in: DOI, Kaggle URL, or institutional archive>` |
| Version or snapshot date | `<fill in>` |
| Licence | `<fill in>` |
| SHA-256 | `<fill in from outputs/segmentation/run_manifest.json>` |

Record the digest here once, after the first successful run. Every subsequent
run recomputes it, so any change to the input file is detected before it can
silently alter the reported numbers.

## Expected schema

Columns consumed by the pipeline:

| Column | Used for |
|---|---|
| `Customer ID` | customer-level aggregation key |
| `Customer Name`, `Segment`, `City`, `State`, `Region` | descriptive attributes carried into the profile export |
| `Order ID` | Frequency (count of distinct orders) |
| `Order Date`, `Ship Date` | Recency, Length, chronological split, temporal features |
| `Sales` | Monetary |
| `Quantity` | Volume |
| `Profit`, `Discount` | profitability attributes, external validation |
| `Product ID`, `Product Name`, `Category` | recommendation module |
| `Ship Mode`, `Shipping_Days`, `Profit_Margin` | derived attributes |

## Preparation

No manual preparation is required. Date parsing, per-customer aggregation, and
LRFMV construction are all performed in `notebooks/01_customer_segmentation.ipynb`
from the raw file.
