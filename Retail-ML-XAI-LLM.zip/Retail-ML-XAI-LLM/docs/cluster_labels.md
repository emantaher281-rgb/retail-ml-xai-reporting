# Cluster identity: how the names are assigned

K-Means returns arbitrary integer labels. The integer a cluster receives
carries no meaning and can change if the input ordering, the seed, or the
library version changes. Business names are therefore assigned **from the
empirical centroids**, never from the raw integer.

## Derivation

Global (customer-weighted) means over all 793 customers:

| Feature | Global mean |
|---|---|
| Length | 1000.65 days |
| Recency | 147.80 days |
| Frequency | 6.32 orders |
| Monetary | $2,896.85 |
| Volume | 47.76 units |

Percentage deviation of each cluster centroid from that global mean:

| Cluster | n | Defining deviations | Assigned name |
|---|---|---|---|
| 0 | 127 | Recency **+207.3%**, Length −49.2%, Monetary −48.8% | Inactive / At-Risk |
| 1 | 407 | Recency −34.9%, Monetary −33.4%, Volume −20.6% | Regular Mid-Value |
| 2 | 259 | Monetary **+76.4%**, Volume +54.8%, Recency −46.8% | High-Value or Active |

The rule is unambiguous: the cluster with by far the highest Recency (customers
who have not purchased in a long time) is the at-risk group; the cluster with
the highest Monetary and Volume is the high-value group; the remaining cluster
sits near the mean on every feature.

## Verification

`src/check_tables.py` reconstructs the customer-weighted global mean from the
exported per-cluster table and asserts that the sign of every reported
deviation agrees with it. This catches label-mapping and sign errors
automatically rather than relying on visual inspection.

## Note on an earlier version

An earlier revision of the export cell mapped cluster 0 to "High-Value or
Active" and cluster 2 to "Inactive / At-Risk" — the two are swapped relative to
the centroids above. That mapping fed `seg_customer_profiles.csv`, which is
consumed by the recommendation and LLM reporting modules, so any artifacts
generated before the fix carry inverted segment names. Regenerate all
downstream artifacts after pulling this version.
