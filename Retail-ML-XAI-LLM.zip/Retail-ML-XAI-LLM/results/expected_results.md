# Expected Results

Reference values from the run reported in the paper. Use these to confirm that
a fresh run reproduces the published numbers.

---

## Module 1 - Customer Segmentation

**Dataset:** 793 customers after per-customer aggregation.

**Selected configuration:** K = 3, K-Means on 2 PCA components of the
standardized LRFMV features.

### Global means (customer-weighted, all 793 customers)

| Feature | Global mean |
|---|---|
| Length | 1000.65 days |
| Recency | 147.80 days |
| Frequency | 6.32 orders |
| Monetary | $2,896.85 |
| Volume | 47.76 units |

### Cluster profiles and deviations

| Cluster | n | Name | Defining deviations from the global mean |
|---|---|---|---|
| 0 | 127 | Inactive / At-Risk | Recency **+207.3%**, Length −49.2%, Monetary −48.8% |
| 1 | 407 | Regular Mid-Value | Recency −34.9%, Monetary −33.4%, Volume −20.6% |
| 2 | 259 | High-Value or Active | Monetary **+76.4%**, Volume +54.8%, Recency −46.8% |

Raw per-cluster means (Monetary): $1,483.03 / $1,929.74 / $5,109.85.
Raw per-cluster means (Recency): 454.17 / 96.23 / 78.62 days.

Consistency: the customer-weighted mean reconstructed from these per-cluster
values reproduces the global means above, and the sign of every deviation
agrees with the side of the mean the raw value falls on. This is checked
automatically by `src/check_tables.py`.

### Cluster naming

Names are derived from the empirical centroids, never from the arbitrary
integer label returned by K-Means. See `docs/cluster_labels.md`.

---

## Modules 2-4

Fill in the reported values from your run:

| Module | Metric | Reported value |
|---|---|---|
| 2 | Precision@K / Recall@K per method | `<from outputs/rec_method_metrics.json>` |
| 3 | Best model, test R² / RMSE / MAE | `<from outputs/product_level_forecast.csv>` |
| 4 | Best model, test R² / RMSE / MAE / MAPE | `<from outputs/fct_model_comparison.csv>` |
| 4 | SHAP vs LIME rank correlation | `<from the notebook output>` |

---

## Module 5 - LLM Decision Reports

**Scope:** 30 customers.

Generated report text is not byte-reproducible: decoding is stochastic and
hosted model snapshots change over time. The structured inputs and prompt
templates are fixed and versioned in `prompts/`, so the inputs to this stage
reproduce exactly. No quantitative table in the paper depends on this module.
