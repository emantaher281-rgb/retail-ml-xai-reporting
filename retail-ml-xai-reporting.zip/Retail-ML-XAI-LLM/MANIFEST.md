# Reproducibility Manifest

A single index mapping every claim made in the manuscript's reproducibility
statement to the file in this repository that supports it. A reviewer should be
able to verify coverage from this page alone, without reading the code.

Repository: `Retail-ML-XAI-LLM`
Paper: *Leveraging Machine Learning and Explainable AI for Enhanced Business
Decision-Making in Retail*

---

## 1. Claim-to-file index

| Claim in the manuscript | Location in this repository |
|---|---|
| The exact Global Superstore dataset file | `data/Customer_Segmentation&Sales_Forecasting_Dataset.csv` — committed; provenance and SHA-256 in `data/README.md` |
| Complete notebooks implementing the full pipeline | `Code/01`–`Code/05`, run in order |
| Preprocessing and feature engineering | `Code/01` (LRFMV, PCA), `Code/04` (lag, rolling, EMA) |
| LRFMV feature construction | `Code/01`; specification in `configuration/segmentation.yaml` → `feature_engineering` |
| Lag / rolling / EMA construction | `Code/04`; specification in `configuration/forecasting.yaml` → `daily.feature_engineering` |
| Training-only aggregation (no leakage) | `configuration/forecasting.yaml` → `daily.leakage_controls`; rolling and EMA features are shifted one step before computation |
| Chronological split information | `configuration/forecasting.yaml` → `daily.cross_validation`; boundary printed by `Code/04` |
| Random split indices | `outputs/split_indices_segmentation.json`, written by `Code/01` |
| Temporal split for recommendation | `Code/02`, cell "TEMPORAL HOLDOUT EVALUATION"; ordering by first-purchase date, most recent 30% held out |
| Random seeds | `SEED = 42` in `src/repro.py`, applied globally and passed to every estimator; enumerated in `docs/reproducibility_checklist.md` §2 |
| Clustering configuration and selected parameters | `configuration/segmentation.yaml` → `clustering` |
| Recommender configuration | `configuration/recommendation.yaml` |
| Candidate generation and ground-truth construction | `configuration/recommendation.yaml` → `candidates` / `ground_truth`; implemented in `Code/02` |
| Hyperparameter search spaces and selected values | `configuration/*.yaml` → `search_space` / `hyperparameters` |
| Evaluation-metric implementations and formulas | `Code/02` (Precision@K, Recall@K, F1@K, Hit Rate, Coverage), `Code/03`–`Code/04` (R², RMSE, MAE, MAPE) |
| SHAP and LIME implementation and evaluation | `Code/01`, `Code/03`, `Code/04` — fidelity, stability, cross-method Spearman rank correlation |
| Exact structured inputs and system prompts for LLaMA-3.3-70B | `prompts/decision_report_prompt.md`; rendered context written to `outputs/` by `Code/05` |
| Python environment and package specifications | `requirements.txt`, `environment.yml`; resolved versions captured in every `outputs/run_manifest_*.json` |
| Consolidated reproducibility manifest | this file |
| Single executable artifact reproducing the results | `run_all.py` |
| README describing structure, environment, and steps | `README.md`, `docs/reproduction_instructions.md` |
| No API keys or credentials included | verified by `verify_package.py` §3; `Code/05` reads credentials from environment variables only |

---

## 2. Verifying the package

Two scripts check the repository rather than asking the reader to take it on
trust:

```bash
python verify_package.py     # every required item present, no outputs, no credentials
python src/check_tables.py   # segmentation deviation signs agree with the raw profiles
```

`verify_package.py` exits non-zero if any required item is missing, if any
notebook carries stored execution output, or if anything resembling an API
credential appears anywhere in the tree. Run it before every push.

---

## 3. Reproducing the reported results

```bash
git clone https://github.com/<username>/Retail-ML-XAI-LLM.git
cd Retail-ML-XAI-LLM
conda env create -f environment.yml && conda activate retail-xai
python run_all.py --skip-llm     # modules 1-4; no credentials needed
python src/check_tables.py
```

Modules 1–4 produce every quantitative table in the manuscript and require no
API credentials. Module 5 generates the written decision reports and needs a
`GROQ_API_KEY`; see `docs/reproduction_instructions.md` §3.

---

## 4. What is deliberately not reproducible bit-for-bit

Stated plainly so that a difference is not mistaken for an error:

- **LLM report text.** Decoding is stochastic and hosted model snapshots
  change. The inputs — structured context and prompt templates — are fixed and
  versioned in `prompts/`. No quantitative table depends on this module.
- **Final decimal places of clustering validity scores.** BLAS threading and
  floating-point reduction order vary across platforms. Cluster memberships and
  all values at manuscript precision are stable; set `OMP_NUM_THREADS=1` for
  tighter agreement.
- **Recommendation split boundary under tied dates.** Where a customer's
  held-out and observed products share the same first-purchase date, their
  relative order is arbitrary. `Code/02` counts and prints these cases.

---

## 5. Generated artifacts

`outputs/` and `figures/` are empty in the repository by design and are
populated when the pipeline runs. Committing them would risk publishing stale
results that no longer match the code. Every run writes
`outputs/run_manifest_<module>.json` recording the seed, the platform, the
resolved package versions, and the dataset SHA-256.
